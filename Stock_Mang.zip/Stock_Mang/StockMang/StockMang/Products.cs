﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StockMang
{
    public partial class Products : Form
    {
        public Products()
        {
            InitializeComponent();
        }

        private void Products_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            LoadData();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (Validation())
            {
                SqlConnection con = Connection.GetConnection();

                //insert logic
                con.Open();
                bool status = true;
                if (comboBox1.SelectedIndex == 0)
                {
                    status = true;
                }
                else
                {
                    status = false;
                }


                var sqlQuery = "";

                if (IfProductsExists(con, txtcode.Text))
                {
                    sqlQuery = @"UPDATE [Product] SET 
      [ProductName] = '" + txtname.Text + "',[ProductStatus] = '" + status + "'  WHERE [ProductCode] = '" + txtcode.Text + "'";
                }
                else
                {
                    sqlQuery = @"INSERT INTO [dbo].[Product] ([ProductCode],[ProductName] ,[ProductStatus]) VALUES('" + txtcode.Text + "','" + txtname.Text + "','" + status + "')";
                }

/*                SqlDataAdapter adp = new SqlDataAdapter("select * from [dbo].[Product]", con);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                */
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();


                //reading data
                LoadData();
                ResetRecords();
            }
        }

        private bool IfProductsExists(SqlConnection con, string productCode)
        {
            SqlDataAdapter adp = new SqlDataAdapter("select 1 from [dbo].[Product] where [ProductCode]='"+productCode+"'",con);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            return true;
        }

        public void LoadData()
        {
            SqlConnection con = Connection.GetConnection();

            SqlDataAdapter adp = new SqlDataAdapter(@"select * from [dbo].[Product]", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.Rows.Clear();

            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["ProductCode"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["ProductName"].ToString();

                if ((bool)item["ProductStatus"])
                {
                    dataGridView1.Rows[n].Cells[2].Value = "Active";
                }
                else
                {
                    dataGridView1.Rows[n].Cells[2].Value = "Deactive";
                }
            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            btnadd.Text = "Update";
            txtcode.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txtname.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            if (dataGridView1.SelectedRows[0].Cells[2].Value.ToString()=="Active")
            {
                comboBox1.SelectedIndex = 0;
            }
            else
            {
                comboBox1.SelectedIndex = 1;
            }
         }

        private void btndel_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure want to Delete", "Message", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                if (Validation())
                {
                    SqlConnection con = Connection.GetConnection();

                    var sqlQuery = "";
                    if (IfProductsExists(con, txtcode.Text))
                    {
                        con.Open();
                        sqlQuery = @"DELETE from [Product] WHERE [ProductCode] = '" + txtcode.Text + "'";

                        SqlCommand cmd = new SqlCommand(sqlQuery, con);
                        cmd.ExecuteNonQuery();
                        con.Close();

                    }
                    else
                    {
                        MessageBox.Show("Record Not Exists.....");
                    }

                    //reading data
                    LoadData();
                    ResetRecords();
                }
            }
        }

        private void ResetRecords()
        {
            txtcode.Clear();
            txtname.Clear();
            comboBox1.SelectedIndex = -1;
            btnadd.Text = "Add";
            txtcode.Focus();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            ResetRecords();
        }

        private bool Validation()
        {
            bool result = false;

            if(string.IsNullOrEmpty(txtcode.Text))
            {
                errorProvider1.Clear();
                errorProvider1.SetError(txtcode," Product Code Required");
            }
            else if(string.IsNullOrEmpty(txtname.Text))
            {
                errorProvider1.Clear();
                errorProvider1.SetError(txtname," Product Name Required");
            }
            else if(comboBox1.SelectedIndex == -1)
            {
                errorProvider1.Clear();
                errorProvider1.SetError(comboBox1,"Select Status"); 
            }
            else
            {
                result = true;
            }

            if (!string.IsNullOrEmpty(txtcode.Text) && !string.IsNullOrEmpty(txtname.Text) && comboBox1.SelectedIndex > -1)
            {
                result = true;
            }
            return result;
        }
    }
}
