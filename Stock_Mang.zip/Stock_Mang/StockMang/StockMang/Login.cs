﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StockMang
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtuname.Text = "";
            txtpwd.Clear();
            txtuname.Focus();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            //TO-DO Check login username & password

            SqlConnection con = Connection.GetConnection();
            SqlDataAdapter adp = new SqlDataAdapter(@"SELECT * 
                    FROM [Stock].[dbo].[Login]
                    where UserName='" + txtuname.Text + "' and Password='" + txtpwd.Text + "'", con);

            DataTable dt = new DataTable();
            adp.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                this.Hide();
                StockMaincs main = new StockMaincs();
                main.Show();
            }
            else
            {
                MessageBox.Show("Invlaid Username & Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                button1_Click(sender, e);
            }
            
        }

        
    }
}
