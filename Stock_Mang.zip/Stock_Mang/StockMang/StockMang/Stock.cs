﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StockMang
{
    public partial class Stock : Form
    {
        public Stock()
        {
            InitializeComponent();
        }

        private void Stock_Load(object sender, EventArgs e)
        {
            this.ActiveControl = dateTimePicker1;
            //comboBox1.SelectedIndex = 0;
            LoadData();
            Search();
        }

        private void dateTimePicker1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txt1.Focus();
            }
        }

        private void txt1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (dgview.Rows.Count > 0)
                {
                    txt1.Text = dgview.SelectedRows[0].Cells[0].Value.ToString();
                    txt2.Text = dgview.SelectedRows[0].Cells[1].Value.ToString();
                    this.dgview.Visible = false;
                    txt3.Focus();
                }
                else
                {
                    this.dgview.Visible = false;
                }
            }
        }

        private void txt2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (txt2.Text.Length > 0)
                {
                    txt3.Focus();
                }
                else
                {
                    txt2.Focus();
                }
            }
        }

        bool change = true;
        private void proCode_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (change)
            {
                change = false;
                txt1.Text = dgview.SelectedRows[0].Cells[0].Value.ToString();
                txt2.Text = dgview.SelectedRows[0].Cells[1].Value.ToString();
                this.dgview.Visible = false;
                txt3.Focus();
                change = true; 
            }
        }

        private void txt3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (txt3.Text.Length > 0)
                {
                    btnadd.Focus();
                }
                else
                {
                    txt3.Focus();
                }
            }
        }
       
        private void txt1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void txt3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void ResetRecords()
        {
            dateTimePicker1.Value = DateTime.Now;
            txt1.Clear();
            txt2.Clear();
            txt3.Clear();
            btnadd.Text = "Add";
            dateTimePicker1.Focus();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            ResetRecords();
        }

        private bool Validation()
        {
            bool result = false;

            if (string.IsNullOrEmpty(txt1.Text))
            {
                errorProvider1.Clear();
                errorProvider1.SetError(txt1, "Product code Required");
            }
            else if (string.IsNullOrEmpty(txt2.Text))
            {
                errorProvider1.Clear();
                errorProvider1.SetError(txt2, "Product Name Required");
            }
            else if (string.IsNullOrEmpty(txt3.Text))
            {
                errorProvider1.Clear();
                errorProvider1.SetError(txt3, "Quantity Required");
            }
            else
            {
                errorProvider1.Clear();
                result = true;
            }
            return result;
        }

        private bool IfProductExists(SqlConnection con, string productCode)
        {
            SqlDataAdapter adp = new SqlDataAdapter("select 1 from [Stock] Where [ProductCode]='" + productCode + "'",con);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (Validation())
            {
                SqlConnection con = Connection.GetConnection();
                con.Open();
               
                var sqlQuery = "";
                if (IfProductExists(con, txt1.Text))
                {
                    sqlQuery = @"UPDATE [Stock] set [ProductName]='" + txt2.Text + "',[Quantity]='" + txt3.Text + "'";
                }
                else
                {
                    sqlQuery = @"Insert into Stock(ProductCode, ProductName, TransDate, Quantity) values('" + txt1.Text + "','" + txt2.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + txt3.Text + "')";
                }

                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record saved Successfully");
                ResetRecords();
            }
        }

        public void LoadData()
        {
            SqlConnection con = Connection.GetConnection();
            SqlDataAdapter adp = new SqlDataAdapter("select * from [Stock].[dbo].[Stock]", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.Rows.Clear();

            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells["dgsrno"].Value = n + 1;
                dataGridView1.Rows[n].Cells["dgProCode"].Value = item["ProductCode"].ToString();
                dataGridView1.Rows[n].Cells["dgProName"].Value = item["ProductName"].ToString();
                dataGridView1.Rows[n].Cells["dgQuantity"].Value = float.Parse(item["Quantity"].ToString());
                dataGridView1.Rows[n].Cells["dgDate"].Value = Convert.ToDateTime(item["TransDate"].ToString()).ToString("dd/MM/yyyy");
            }
            if (dataGridView1.Rows.Count > 0)
            {
                label8.Text = dataGridView1.Rows.Count.ToString();
                float totQty = 0;
                for (int i = 0; i < dataGridView1.Rows.Count; ++i)
                {
                    totQty += float.Parse(dataGridView1.Rows[i].Cells[3].Value.ToString());
                    label9.Text = totQty.ToString();
                }
            }
            else
            {
                label8.Text = "0";
                label9.Text = "0";
            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            btnadd.Text = "Update";
            txt1.Text = dataGridView1.SelectedRows[0].Cells["dgProCode"].Value.ToString();
            txt2.Text = dataGridView1.SelectedRows[0].Cells["dgProName"].Value.ToString();
            txt3.Text = dataGridView1.SelectedRows[0].Cells["dgQuantity"].Value.ToString();
            //dateTimePicker1.Text = dataGridView1.SelectedRows[0].Cells["dgDate"].Value.ToString();
          
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure wnat to Delete", "Message", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                if (Validation())
                {
                    SqlConnection con = Connection.GetConnection();
                    var sqlQuery = "";
                    if (IfProductExists(con, txt1.Text))
                    {
                        con.Open();
                        sqlQuery = @"Delete from [Stock] where [ProductCode]='" + txt1.Text + "'";
                        SqlCommand cmd = new SqlCommand(sqlQuery, con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    else
                    {
                        MessageBox.Show("Recored Not Exists...");
                    }
                    LoadData();
                    ResetRecords();
                }
            }

        }

        private void txt1_TextChanged(object sender, EventArgs e)
        {
            if (txt1.Text.Length > 0)
            {
                this.dgview.Visible = true;
                dgview.BringToFront();
                Search(150, 105, 430, 200, "Pro Code, Pro Name", "100,0");
                this.dgview.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.proCode_MouseDoubleClick);
                SqlConnection con = Connection.GetConnection();
                con.Open();
                SqlDataAdapter adp = new SqlDataAdapter("Select Top(10) ProductCode,ProductName From Product where [ProductCode] Like '" + txt1.Text + "%'", con);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                dgview.Rows.Clear();

                foreach(DataRow row in dt.Rows)
                {
                    int n = dgview.Rows.Add();
                    dgview.Rows[n].Cells[0].Value = row["ProductCode"].ToString();
                    dgview.Rows[n].Cells[1].Value = row["ProductName"].ToString();
                }
            }
            else
            {
                dgview.Visible = false;
            }
        }

        private DataGridView dgview;
        private DataGridViewTextBoxColumn dgviewcol1;
        private DataGridViewTextBoxColumn dgviewcol2;

        void Search()
        {
            dgview = new DataGridView();
            dgviewcol1 = new DataGridViewTextBoxColumn();
            dgviewcol2 = new DataGridViewTextBoxColumn();

            this.dgview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[]{
                this.dgviewcol1,
                this.dgviewcol2
            });
            this.dgview.Name = "dgview";
            dgview.Visible = false;
            this.dgviewcol1.Visible = false;
            this.dgviewcol2.Visible = false;

            this.dgview.AllowUserToAddRows = false;
            this.dgview.RowHeadersVisible = false;
            this.dgview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;

            this.Controls.Add(dgview);
            this.dgview.ReadOnly = true;
            dgview.BringToFront();
        }

        void Search(int LX,int LY,int DW,int DH,string ColName,string ColSize)
        {
            this.dgview.Location = new System.Drawing.Point(LX, LY);
            this.dgview.Size = new System.Drawing.Size(DW, DH);

            string[] ClSize = ColSize.Split(',');

            for (int i = 0; i < ClSize.Length; i++)
            {
                if (int.Parse(ClSize[i]) != 0)
                {
                    dgview.Columns[i].Width = int.Parse(ClSize[i]);
                }
                else
                {
                    dgview.Columns[i].AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
                }
            }

            string[] ClName = ColName.Split(',');

            for (int i = 0; i < ClName.Length; i++)
            {
                this.dgview.Columns[i].HeaderText = ClName[i];
                this.dgview.Columns[i].Visible = true;
            }
        }


    }
}
