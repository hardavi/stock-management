﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace StockMang.ReportForm
{
    public partial class ProductsReport : Form
    {
        ReportDocument crypt = new ReportDocument();

        public ProductsReport()
        {
            InitializeComponent();
        }

        private void ProductsReport_Load(object sender, EventArgs e)
        {
           // this.reportViewer1.RefreshReport();
            crypt.Load(@"C:\Users\manis\Desktop\project_asp.net\Stock_Mang\StockMang\StockMang\Reports\Product.rpt");
            SqlConnection con = Connection.GetConnection();
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter adp = new SqlDataAdapter("select * from [Product]",con);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            crypt.SetDataSource(dt);
            crystalReportViewer1.ReportSource = crypt;
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }

        
    }
}
