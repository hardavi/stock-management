﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;
using CrystalDecisions.Shared;

namespace StockMang.ReportForm
{
    public partial class StockReport : Form
    {
        ReportDocument crypt = new ReportDocument();

        public StockReport()
        {
            InitializeComponent();
        }

        private void StockReport_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            crypt.Load(@"C:\Users\manis\Desktop\project_asp.net\Stock_Mang\StockMang\StockMang\Reports\Stock.rpt");
            SqlConnection con = Connection.GetConnection();
            con.Open();

            DataSet ds = new DataSet();
            SqlDataAdapter adp = new SqlDataAdapter("select * from [Stock] where Cast(TransDate as Date) between '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and '" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "' ", con);
            adp.Fill(ds,"Stock");
            crypt.SetDataSource(ds);
            crypt.SetParameterValue("@FromDate",dateTimePicker1.Value.ToString("dd/MM/yyyy"));
            crypt.SetParameterValue("@ToDate",dateTimePicker2.Value.ToString("dd/MM/yyyy"));
            crystalReportViewer1.ReportSource = crypt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ExportOptions exportOption;
            DiskFileDestinationOptions diskFileDestinationOptions = new DiskFileDestinationOptions();
            SaveFileDialog sfd = new SaveFileDialog();
            //sfd.Filter = "PDF Files|*.pdf";
            sfd.Filter = "Excel|*.xls";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                diskFileDestinationOptions.DiskFileName = sfd.FileName;
            }
            exportOption = crypt.ExportOptions;
            {
                //PDF
               // exportOption.ExportDestinationType = ExportDestinationType.DiskFile;
                //exportOption.ExportFormatType = ExportFormatType.PortableDocFormat;
                //exportOption.ExportDestinationOptions = diskFileDestinationOptions;
                //exportOption.ExportFormatOptions = new PdfRtfWordFormatOptions();
                
                //Excel Format
                exportOption.ExportDestinationType = ExportDestinationType.DiskFile;
                exportOption.ExportFormatType = ExportFormatType.Excel;
                exportOption.ExportDestinationOptions = diskFileDestinationOptions;
                exportOption.ExportFormatOptions = new ExcelFormatOptions();
            }
            crypt.Export();
        }
    }
}
